import {
  createSubCategoryService,
  getSubCategoriesService,
  getSubCategoryByIdService,
  updateSubCategoryService,
  deleteSubCategoryService
} from '../services/subcategory.service.js';

import {
  createSubCategorySchema,
  updateSubCategorySchema
} from '../validations/subcategory.validation.js';

/**
 * Create SubCategory
 */
export const createSubCategory = async (req, res, next) => {
  try {
    const { error } = createSubCategorySchema.validate(req.body);
    if (error) {
      res.status(400);
      throw new Error(error.message);
    }

    const subCategory = await createSubCategoryService(req.body);
    res.status(201).json({ success: true, data: subCategory });
  } catch (err) {
    next(err);
  }
};

/**
 * Get SubCategories
 */
export const getSubCategories = async (req, res, next) => {
  try {
    const result = await getSubCategoriesService(req.query);
    res.status(200).json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
};

/**
 * Get SubCategory by ID
 */
export const getSubCategoryById = async (req, res, next) => {
  try {
    const subCategory = await getSubCategoryByIdService(req.params.id);
    res.status(200).json({ success: true, data: subCategory });
  } catch (err) {
    next(err);
  }
};

/**
 * Update SubCategory
 */
export const updateSubCategory = async (req, res, next) => {
  try {
    const { error } = updateSubCategorySchema.validate(req.body);
    if (error) {
      res.status(400);
      throw new Error(error.message);
    }

    const subCategory = await updateSubCategoryService(req.params.id, req.body);
    res.status(200).json({ success: true, data: subCategory });
  } catch (err) {
    next(err);
  }
};

/**
 * Soft Delete SubCategory
 */
export const deleteSubCategory = async (req, res, next) => {
  try {
    await deleteSubCategoryService(req.params.id);
    res.status(200).json({ success: true, message: 'SubCategory deleted successfully' });
  } catch (err) {
    next(err);
  }
};
