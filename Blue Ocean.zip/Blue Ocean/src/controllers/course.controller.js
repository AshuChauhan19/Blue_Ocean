import {
  createCourseService,
  getCoursesService,
  getCourseByIdService,
  updateCourseService,
  deleteCourseService
} from '../services/course.service.js';

import {
  createCourseSchema,
  updateCourseSchema
} from '../validations/course.validation.js';

/**
 * Create Course (transaction + validation)
 */
export const createCourse = async (req, res, next) => {
  try {
    const { error } = createCourseSchema.validate(req.body);
    if (error) {
      res.status(400);
      throw new Error(error.message);
    }

    const course = await createCourseService(req.body);
    res.status(201).json({ success: true, data: course });
  } catch (err) {
    next(err);
  }
};

/**
 * Get Courses
 */
export const getCourses = async (req, res, next) => {
  try {
    const result = await getCoursesService(req.query);
    res.status(200).json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
};

/**
 * Get Course by ID
 */
export const getCourseById = async (req, res, next) => {
  try {
    const course = await getCourseByIdService(req.params.id);
    res.status(200).json({ success: true, data: course });
  } catch (err) {
    next(err);
  }
};

/**
 * Update Course
 */
export const updateCourse = async (req, res, next) => {
  try {
    const { error } = updateCourseSchema.validate(req.body);
    if (error) {
      res.status(400);
      throw new Error(error.message);
    }

    const course = await updateCourseService(req.params.id, req.body);
    res.status(200).json({ success: true, data: course });
  } catch (err) {
    next(err);
  }
};

/**
 * Soft Delete Course
 */
export const deleteCourse = async (req, res, next) => {
  try {
    await deleteCourseService(req.params.id);
    res.status(200).json({ success: true, message: 'Course deleted successfully' });
  } catch (err) {
    next(err);
  }
};
