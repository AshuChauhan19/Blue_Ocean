import SubCategory from '../models/subcategory.model.js';
import Category from '../models/category.model.js';
import { apiFeatures } from '../utils/apiFeatures.js';

/**
 * Create SubCategory (Category validation)
 */
export const createSubCategoryService = async (data) => {
  // Check if category exists
  const category = await Category.findOne({
    _id: data.categoryId,
    isDeleted: false
  });

  if (!category) {
    throw new Error('Invalid Category');
  }

  // Check duplicate subcategory name under same category
  const existingSubCategory = await SubCategory.findOne({
    name: data.name,
    categoryId: data.categoryId,
    isDeleted: false
  });

  if (existingSubCategory) {
    throw new Error('SubCategory already exists');
  }

  return await SubCategory.create(data);
};

/**
 * Get SubCategories
 */
export const getSubCategoriesService = async (query) => {
  const page = parseInt(query.page) || 1;
  const limit = parseInt(query.limit) || 10;
  const skip = (page - 1) * limit;

  const sort = query.sort || '-createdAt';

  // Base filter (soft delete)
  const filter = { isDeleted: false };

  // 🔍 Search by subcategory name
  if (query.search) {
    filter.name = { $regex: query.search, $options: 'i' };
  }

  // 🧰 Filter by category
  if (query.categoryId) {
    filter.categoryId = query.categoryId;
  }

  const data = await SubCategory.find(filter)
    .populate('categoryId', 'name')
    .sort(sort)
    .skip(skip)
    .limit(limit);

  const total = await SubCategory.countDocuments(filter);

  return {
    page,
    limit,
    total,
    count: data.length,
    data
  };
};

/**
 * Get SubCategory by ID
 */
export const getSubCategoryByIdService = async (id) => {
  const subCategory = await SubCategory.findOne({
    _id: id,
    isDeleted: false
  }).populate('categoryId', 'name');

  if (!subCategory) throw new Error('SubCategory not found');
  return subCategory;
};

/**
 * Update SubCategory
 */
export const updateSubCategoryService = async (id, data) => {
  if (data.categoryId) {
    const category = await Category.findOne({
      _id: data.categoryId,
      isDeleted: false
    });

    if (!category) throw new Error('Invalid Category');
  }

  const subCategory = await SubCategory.findOneAndUpdate(
    { _id: id, isDeleted: false },
    data,
    { new: true }
  );

  if (!subCategory) throw new Error('SubCategory not found');
  return subCategory;
};

/**
 * Soft Delete SubCategory
 */
export const deleteSubCategoryService = async (id) => {
  const subCategory = await SubCategory.findOneAndUpdate(
    { _id: id },
    { isDeleted: true },
    { new: true }
  );

  if (!subCategory) throw new Error('SubCategory not found');
};
