import { Router } from 'express';
import {
  createCourse,
  getCourses,
  getCourseById,
  updateCourse,
  deleteCourse
} from '../controllers/course.controller.js';

const router = Router();

// Create Course (with transaction & validation)
router.post('/', createCourse);

// Get all courses
router.get('/', getCourses);

// Get course by ID
router.get('/:id', getCourseById);

// Update course
router.put('/:id', updateCourse);

// Soft delete course
router.delete('/:id', deleteCourse);

export default router;
