import Category from '../models/category.model.js';
import { apiFeatures } from '../utils/apiFeatures.js';

/**
 * Create Category
 */
export const createCategoryService = async (data) => {
  const existingCategory = await Category.findOne({
    name: data.name,
    isDeleted: false
  });

  if (existingCategory) {
    throw new Error('Category already exists');
  }

  return await Category.create(data);
};

/**
 * Get Categories (pagination, search, sort)
 */
export const getCategoriesService = async (query) => {
  const page = parseInt(query.page) || 1;
  const limit = parseInt(query.limit) || 10;
  const skip = (page - 1) * limit;

  const sort = query.sort || '-createdAt';

  // Base filter (soft delete)
  const filter = { isDeleted: false };

  // 🔍 Search by name
  if (query.search) {
    filter.name = { $regex: query.search, $options: 'i' };
  }

  // 🧰 Additional filtering (example: by name exact)
  if (query.name) {
    filter.name = query.name;
  }

  const data = await Category.find(filter)
    .sort(sort)
    .skip(skip)
    .limit(limit);

  const total = await Category.countDocuments(filter);

  return {
    page,
    limit,
    total,
    count: data.length,
    data
  };
};

/**
 * Get Category by ID
 */
export const getCategoryByIdService = async (id) => {
  const category = await Category.findOne({ _id: id, isDeleted: false });
  if (!category) throw new Error('Category not found');
  return category;
};

/**
 * Update Category
 */
export const updateCategoryService = async (id, data) => {
  // Check duplicate name (excluding current category)
  if (data.name) {
    const existingCategory = await Category.findOne({
      name: data.name,
      isDeleted: false,
      _id: { $ne: id }
    });

    if (existingCategory) {
      throw new Error('Category already exists');
    }
  }

  const category = await Category.findOneAndUpdate(
    { _id: id, isDeleted: false },
    data,
    { new: true }
  );

  if (!category) throw new Error('Category not found');

  return category;
};

/**
 * Soft Delete Category
 */
export const deleteCategoryService = async (id) => {
  const category = await Category.findOneAndUpdate(
    { _id: id },
    { isDeleted: true },
    { new: true }
  );

  if (!category) throw new Error('Category not found');
};

/**
 * Aggregation: Category with SubCategory Count
 */
export const getCategorySubCategoryCountService = async () => {
  return await Category.aggregate([
    { $match: { isDeleted: false } },
    {
      $lookup: {
        from: 'subcategories',
        localField: '_id',
        foreignField: 'categoryId',
        as: 'subCategories'
      }
    },
    {
      $project: {
        name: 1,
        subCategoryCount: { $size: '$subCategories' }
      }
    }
  ]);
};