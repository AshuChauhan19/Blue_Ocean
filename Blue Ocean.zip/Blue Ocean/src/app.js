import express from 'express';
import morgan from 'morgan';
import categoryRoutes from './routes/category.routes.js';
import subcategoryRoutes from './routes/subcategory.routes.js';
import courseRoutes from './routes/course.routes.js';
import { notFound, errorHandler } from './utils/errorHandler.js';

const app = express();

// Middleware
app.use(express.json());
app.use(morgan('dev'));

// Routes
app.use('/api/categories', categoryRoutes);
app.use('/api/subcategories', subcategoryRoutes);
app.use('/api/courses', courseRoutes);

// 404 Handler
app.use(notFound);

// Global Error Handler
app.use(errorHandler);

export default app;
