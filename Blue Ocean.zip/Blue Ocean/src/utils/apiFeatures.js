export const apiFeatures = (queryParams) => {
  const page = Math.max(parseInt(queryParams.page) || 1, 1);
  const limit = Math.max(parseInt(queryParams.limit) || 10, 1);
  const skip = (page - 1) * limit;

  const sort = queryParams.sort || '-createdAt';

  const filter = { isDeleted: false };

  // Search by name or title
  if (queryParams.search) {
    filter.$or = [
      { name: { $regex: queryParams.search, $options: 'i' } },
      { title: { $regex: queryParams.search, $options: 'i' } }
    ];
  }

  return { page, limit, skip, sort, filter};
};
