import Joi from 'joi';

// Create SubCategory
export const createSubCategorySchema = Joi.object({
  name: Joi.string().trim().min(2).max(100).required(),
  categoryId: Joi.string().length(24).required()
});

// Update SubCategory
export const updateSubCategorySchema = Joi.object({
  name: Joi.string().trim().min(2).max(100).optional(),
  categoryId: Joi.string().length(24).optional()
});
