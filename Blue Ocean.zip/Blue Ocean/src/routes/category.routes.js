import { Router } from 'express';
import {
  createCategory,
  getCategories,
  getCategoryById,
  updateCategory,
  deleteCategory,
  getCategorySubCategoryCount
} from '../controllers/category.controller.js';

const router = Router();

// Create Category
router.post('/', createCategory);

// Get all categories (pagination, search, sort)
router.get('/', getCategories);

// Get category by ID
router.get('/:id', getCategoryById);

// Update category
router.put('/:id', updateCategory);

// Soft delete category
router.delete('/:id', deleteCategory);

// Aggregation: category with subcategory count
router.get('/aggregation/subcategory-count', getCategorySubCategoryCount);

export default router;
