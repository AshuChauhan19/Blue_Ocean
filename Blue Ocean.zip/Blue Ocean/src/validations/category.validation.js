import Joi from 'joi';

// Create Category
export const createCategorySchema = Joi.object({
  name: Joi.string().trim().min(2).max(100).required()
});

// Update Category
export const updateCategorySchema = Joi.object({
  name: Joi.string().trim().min(2).max(100).optional()
});
