import mongoose from 'mongoose';
import Course from '../models/course.model.js';
import Category from '../models/category.model.js';
import SubCategory from '../models/subcategory.model.js';
import { apiFeatures } from '../utils/apiFeatures.js';

/**
 * Create Course (Transaction + Business Rule Validation)
 */
export const createCourseService = async (data) => {
  // Check duplicate course
  const courseExists = await Course.findOne({
    title: data.title,
    isDeleted: false
  });

  if (courseExists) {
    throw new Error('Course already exists');
  }

  // Validate categories
  const categories = await Category.find({
    _id: { $in: data.categoryIds },
    isDeleted: false
  });

  if (categories.length !== data.categoryIds.length) {
    throw new Error('Invalid Categories');
  }

  // Validate subcategories
  const subCategories = await SubCategory.find({
    _id: { $in: data.subCategoryIds },
    isDeleted: false
  });

  if (subCategories.length !== data.subCategoryIds.length) {
    throw new Error('Invalid SubCategories');
  }

  // Business rule validation
  const isInvalid = subCategories.some(
    (sc) => !data.categoryIds.includes(sc.categoryId.toString())
  );

  if (isInvalid) {
    throw new Error('SubCategories must belong to selected Categories');
  }

  // Create course
  return await Course.create(data);
};

/**
 * Get Courses
 */
export const getCoursesService = async (query) => {
  const page = parseInt(query.page) || 1;
  const limit = parseInt(query.limit) || 10;
  const skip = (page - 1) * limit;

  const sort = query.sort || '-createdAt';

  const filter = { isDeleted: false };

  if (query.search) {
    filter.title = { $regex: query.search, $options: 'i' };
  }

  if (query.categoryId) {
    filter.categoryIds = query.categoryId;
  }

  if (query.subCategoryId) {
    filter.subCategoryIds = query.subCategoryId;
  }

  const data = await Course.find(filter)
    .populate('categoryIds', 'name')
    .populate('subCategoryIds', 'name')
    .sort(sort)
    .skip(skip)
    .limit(limit);

  const total = await Course.countDocuments(filter);

  return {
    page,
    limit,
    total,
    count: data.length,
    data
  };
};

/**
 * Get Course by ID
 */
export const getCourseByIdService = async (id) => {
  const course = await Course.findOne({
    _id: id,
    isDeleted: false
  })
    .populate('categoryIds', 'name')
    .populate('subCategoryIds', 'name');

  if (!course) throw new Error('Course not found');
  return course;
};

/**
 * Update Course
 */
export const updateCourseService = async (id, data) => {
  const course = await Course.findOneAndUpdate(
    { _id: id, isDeleted: false },
    data,
    { new: true }
  );

  if (!course) throw new Error('Course not found');
  return course;
};

/**
 * Soft Delete Course
 */
export const deleteCourseService = async (id) => {
  const course = await Course.findOneAndUpdate(
    { _id: id },
    { isDeleted: true },
    { new: true }
  );

  if (!course) throw new Error('Course not found');
};
