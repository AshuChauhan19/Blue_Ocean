import Joi from 'joi';

// Create Course
export const createCourseSchema = Joi.object({
  title: Joi.string().trim().min(2).max(200).required(),

  categoryIds: Joi.array()
    .items(Joi.string().length(24))
    .min(1)
    .required(),

  subCategoryIds: Joi.array()
    .items(Joi.string().length(24))
    .min(1)
    .required()
});

// Update Course
export const updateCourseSchema = Joi.object({
  title: Joi.string().trim().min(2).max(200).optional(),

  categoryIds: Joi.array()
    .items(Joi.string().length(24))
    .optional(),

  subCategoryIds: Joi.array()
    .items(Joi.string().length(24))
    .optional()
});
