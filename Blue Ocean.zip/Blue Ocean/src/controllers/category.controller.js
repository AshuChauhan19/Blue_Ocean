import {
  createCategoryService,
  getCategoriesService,
  getCategoryByIdService,
  updateCategoryService,
  deleteCategoryService,
  getCategorySubCategoryCountService
} from '../services/category.service.js';

import {
  createCategorySchema,
  updateCategorySchema
} from '../validations/category.validation.js';

/**
 * Create Category
 */
export const createCategory = async (req, res, next) => {
  try {
    const { error } = createCategorySchema.validate(req.body);
    if (error) {
      res.status(400);
      throw new Error(error.message);
    }

    const category = await createCategoryService(req.body);
    res.status(201).json({ success: true, data: category });
  } catch (err) {
    next(err);
  }
};

/**
 * Get Categories (pagination, search, sort)
 */
export const getCategories = async (req, res, next) => {
  try {
    const result = await getCategoriesService(req.query);
    res.status(200).json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
};

/**
 * Get Category by ID
 */
export const getCategoryById = async (req, res, next) => {
  try {
    const category = await getCategoryByIdService(req.params.id);
    res.status(200).json({ success: true, data: category });
  } catch (err) {
    next(err);
  }
};

/**
 * Update Category
 */
export const updateCategory = async (req, res, next) => {
  try {
    const { error } = updateCategorySchema.validate(req.body);
    if (error) {
      res.status(400);
      throw new Error(error.message);
    }

    const category = await updateCategoryService(req.params.id, req.body);
    res.status(200).json({ success: true, data: category });
  } catch (err) {
    next(err);
  }
};

/**
 * Soft Delete Category
 */
export const deleteCategory = async (req, res, next) => {
  try {
    await deleteCategoryService(req.params.id);
    res.status(200).json({ success: true, message: 'Category deleted successfully' });
  } catch (err) {
    next(err);
  }
};

/**
 * Aggregation: Category with SubCategory Count
 */
export const getCategorySubCategoryCount = async (req, res, next) => {
  try {
    const data = await getCategorySubCategoryCountService();
    res.status(200).json({ success: true, data });
  } catch (err) {
    next(err);
  }
};
