import { Router } from 'express';
import {
  createSubCategory,
  getSubCategories,
  getSubCategoryById,
  updateSubCategory,
  deleteSubCategory
} from '../controllers/subcategory.controller.js';

const router = Router();

// Create SubCategory
router.post('/', createSubCategory);

// Get all subcategories
router.get('/', getSubCategories);

// Get subcategory by ID
router.get('/:id', getSubCategoryById);

// Update subcategory
router.put('/:id', updateSubCategory);

// Soft delete subcategory
router.delete('/:id', deleteSubCategory);

export default router;
